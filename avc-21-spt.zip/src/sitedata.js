var data = {
  // "path"          : "http://localhost:5001/api/v4",
  // "live_site"  : "https://aimedis.io/",
  // "path"       : "https://aidoc.io/api/v3",
  // "path"       : "https://sys.aimedis.io/api/v3",
  "path": 'https://virtualhospital.aidoc.io/api/v4',
  // "path": "https://aimedix.com/api/v4"
};
exports.data = data;
